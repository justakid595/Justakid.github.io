
import QuizApp from '../components/QuizApp';

const Index = () => {
  return <QuizApp />;
};

export default Index;
